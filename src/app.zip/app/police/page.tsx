// src/app/khor-kor/page.tsx
export const revalidate = 0; 

import Link from 'next/link';
import { createSupabaseServerClient } from '@/lib/supabase/server'; // ใช้ alias ใหม่

interface Test {
  id: string;
  title: string;
  duration_mins: number;
  is_premium: boolean;
}

export default async function KhorKorPage() {
  const supabase = createSupabaseServerClient();
  
  // ดึงข้อมูลจากตาราง Tests โดยใช้เงื่อนไข exam_category = 'KHOR_KOR'
  const { data: tests, error } = await supabase
    .from('Tests')
    .select('id, title, duration_mins, is_premium')
    .eq('exam_category', 'POLICE'); // <<<< ค้นหาหมวด KHOR_KOR

  if (error) {
    console.error('Error fetching tests:', error.message);
    return <div className="text-center py-20 text-red-600">เกิดข้อผิดพลาดในการโหลดชุดข้อสอบ: {error.message}</div>;
  }
  
  return (
    <div className="container mx-auto p-8 min-h-screen bg-gray-50">
      <h1 className="text-4xl font-bold text-gray-800 mb-6">รวมชุดข้อสอบนายร้อยตำรวจ 📝</h1>
      <p className="text-lg text-gray-600 mb-10">เตรียมสอบความรู้ความสามารถทั่วไป (คณิตศาสตร์ ภาษาไทย และกฎหมาย)</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {tests?.map((test: Test) => (
          <Link 
            href={`/test/${test.id}`} 
            key={test.id} 
            className="block p-5 bg-white border border-gray-200 rounded-lg shadow-md hover:shadow-lg transition duration-300"
          >
            <h2 className="text-xl font-semibold text-indigo-700">
              {test.title} 
              {test.is_premium && (
                <span className="ml-3 text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full font-medium">PREMIUM</span>
              )}
            </h2>
            <p className="text-gray-500 mt-2">
              ระยะเวลา: {test.duration_mins} นาที
            </p>
            <div className="mt-4 text-indigo-600 font-medium">
              เริ่มทำข้อสอบ &rarr;
            </div>
          </Link>
        ))}
      </div>
      
      {(!tests || tests.length === 0) && (
        <div className="text-center py-10 text-gray-500">
          ไม่พบชุดข้อสอบนายร้อยตำรวจ ในระบบ
        </div>
      )}
    </div>
  );
}