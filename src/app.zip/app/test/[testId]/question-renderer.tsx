// src/app/test/[testId]/question-renderer.tsx
'use client'; 

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation'; 
import Link from 'next/link';
import { supabase } from '@/lib/supabase/client'; 
import { getLocalUsername } from '@/app/components/NamePrompt'; 

// ... (Types เหมือนเดิม)
interface Question {
    id: string; test_id: string; question_text: string; choices: string[];
    correct_index: number; explanation: string;
}
interface Props {
    initialQuestions: Question[]; testTitle: string; isPaywalled: boolean; 
}

// ==== Component ====
export default function QuestionRenderer({ initialQuestions, testTitle, isPaywalled }: Props) {
    const [userAnswers, setUserAnswers] = useState<Record<string, number>>({});
    const [startTime] = useState(Date.now()); 
    const [isSaving, setIsSaving] = useState(false); 
    
    const router = useRouter();
    const userName = getLocalUsername(); 
    const totalQuestions = initialQuestions.length;
    const answeredCount = Object.keys(userAnswers).length;

    // === ฟังก์ชันจัดการการตอบ ===
    const handleAnswer = (questionId: string, selectedIndex: number) => {
        if (userAnswers[questionId] !== undefined) return; 

        setUserAnswers(prev => ({
            ...prev,
            [questionId]: selectedIndex,
        }));
    };

    // === Logic: ตรวจสอบและบันทึกผลลัพธ์เมื่อตอบครบ ===
    useEffect(() => {
        if (answeredCount === totalQuestions && totalQuestions > 0 && !isSaving) {
            setIsSaving(true);
            
            let correctCount = 0;
            const timeSpentSecs = Math.floor((Date.now() - startTime) / 1000);
            const testId = initialQuestions[0].test_id; 

            // 1. คำนวณคะแนนและเตรียมข้อมูล
            const answerDetails = initialQuestions.map(q => {
                const isCorrect = userAnswers[q.id] === q.correct_index;
                if (isCorrect) correctCount++;
                return {
                    question_id: q.id,
                    submitted_choice: userAnswers[q.id],
                    is_correct: isCorrect,
                };
            });
            
            const scorePercent = (correctCount / totalQuestions) * 100;
            
            // 2. ข้อมูลสรุปสำหรับการ Insert ลง TestAttempt
            const attemptSummary = {
                user_identifier: userName || 'Anonymous', 
                test_id: testId,
                end_time: new Date().toISOString(),
                score: correctCount,
                total_questions: totalQuestions,
                score_percent: scorePercent, 
                time_spent_secs: timeSpentSecs
            };

            async function saveResults() {
                // A) บันทึกสรุป (TestAttempt)
                const { data: attemptData, error: attemptError } = await supabase
                    .from('TestAttempt') 
                    .insert([attemptSummary])
                    .select('id'); 

                if (attemptError || !attemptData || attemptData.length === 0) {
                    console.error('Error saving attempt summary:', attemptError?.message);
                    alert('ไม่สามารถบันทึกสรุปผลลัพธ์ได้ กรุณาตรวจสอบ RLS Policy ของ TestAttempt');
                    return;
                }
                
                const attemptId = attemptData[0].id;
                
                // B) บันทึกคำตอบรายข้อ (UserAnswer)
                const answersToInsert = answerDetails.map(ans => ({
                    ...ans,
                    attempt_id: attemptId
                }));

                const { error: answersError } = await supabase
                    .from('UserAnswer')
                    .insert(answersToInsert);

                if (answersError) {
                     console.error('Warning: Error saving detailed answers:', answersError.message);
                }

                // C) นำทางไปยังหน้าสรุปผล
                router.push(`/result/${attemptId}`);
            }

            saveResults();
        }
    }, [answeredCount, totalQuestions, initialQuestions, startTime, router, userAnswers, isSaving, userName]);
    
    // ... (UI ส่วนแสดงผล)
    return (
        <div className="space-y-12">
            
            {/* ส่วนหัว: แสดงชื่อผู้ใช้และความคืบหน้า */}
            <div className="mb-8 text-center bg-white p-6 rounded-lg shadow-inner">
                <h2 className="text-2xl font-bold text-indigo-700">{testTitle}</h2>
                <p className="text-gray-600 mt-2">
                  ยินดีต้อนรับ,{' '}
                <span className="font-semibold text-gray-800">
                    {userName || 'ผู้ใช้งาน'}
                </span>
                </p>
            </div>

            {/* วนลูปแสดงโจทย์แต่ละข้อ */}
            {initialQuestions.map((q, index) => {
                const selectedAnswerIndex = userAnswers[q.id];
                const isAnswered = selectedAnswerIndex !== undefined;
                const isCorrect = isAnswered && selectedAnswerIndex === q.correct_index;

                return (
                    <div key={q.id} className="p-6 border rounded-xl shadow-sm bg-white hover:shadow-md transition">
                        <p className="text-lg font-semibold mb-4">
                            ข้อที่ {index + 1}: {q.question_text}
                        </p>

                        {/* ส่วนแสดงตัวเลือก */}
                        <div className="space-y-3">
                            {Array.isArray(q.choices) && q.choices.map((choice, choiceIndex) => {
                                const isChoiceCorrect = isAnswered && choiceIndex === q.correct_index;
                                const isChoiceSelected = selectedAnswerIndex === choiceIndex;
                                
                                const bgColor = isAnswered
                                    ? isChoiceCorrect ? 'bg-green-100 border-green-500' 
                                    : isChoiceSelected ? 'bg-red-100 border-red-500'     
                                    : 'bg-white'                       
                                    : 'bg-white hover:bg-gray-100';      

                                return (
                                    <label 
                                        key={choiceIndex} 
                                        className={`flex items-center p-3 rounded-md border transition cursor-pointer ${bgColor}`}
                                    >
                                        <input 
                                            type="radio" 
                                            name={`question-${q.id}`} 
                                            value={choiceIndex}
                                            checked={isChoiceSelected}
                                            onChange={() => handleAnswer(q.id, choiceIndex)}
                                            disabled={isAnswered} 
                                            className="form-radio h-5 w-5 text-indigo-600 disabled:opacity-50"
                                        />
                                        <span className="ml-3 text-gray-700">
                                            {String.fromCharCode(65 + choiceIndex)}. {choice}
                                        </span>
                                    </label>
                                );
                            })}
                        </div>

                        {/* ส่วนแสดงเฉลยและคำอธิบาย (แสดงเมื่อตอบแล้วเท่านั้น) */}
                        {isAnswered && (
                            <div
                                className={`mt-4 p-4 rounded-lg font-medium ${
                                    isCorrect ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
                                }`}
                            >
                                <h4 className="font-bold mb-2">
                                    {isCorrect ? '✅ ถูกต้อง!' : `❌ ผิด! คำตอบที่ถูกคือ ${String.fromCharCode(65 + q.correct_index)}`}
                                </h4>
                                
                                {/* <<<<<<< PAYWALL LOGIC >>>>>>> */}
                                {isPaywalled ? ( // ถ้าเป็นชุด Premium ให้แสดง Paywall
                                    <div className="mt-2 p-3 bg-yellow-100 text-yellow-800 border border-yellow-500 rounded-md">
                                        <h5 className="font-bold">🔓 ล็อกคำอธิบายโดยละเอียด</h5>
                                        <p className="text-sm mt-1">
                                            คำอธิบายนี้สงวนไว้สำหรับสมาชิก Premium เท่านั้น! 
                                            <Link href="/premium" className="text-indigo-600 underline font-semibold ml-2">
                                                อัปเกรดเพื่อปลดล็อก (บังคับ Login)
                                            </Link>
                                        </p>
                                    </div>
                                ) : ( // ถ้าเป็นชุดฟรี ให้แสดงคำอธิบาย
                                    q.explanation && (
                                        <p className="text-sm border-t border-dashed pt-2 mt-2">
                                            💡 คำอธิบายโดยละเอียด: {q.explanation}
                                        </p>
                                    )
                                )}
                            </div>
                        )}
                    </div>
                );
            })}
            
            {/* ปุ่มส่งคำตอบ (แสดงสถานะกำลังบันทึก) */}
            <div className="mt-12 text-center">
                 <button 
                    type="button" 
                    className="px-12 py-3 bg-indigo-600 text-white font-bold text-xl rounded-lg shadow-lg disabled:bg-gray-400 disabled:cursor-not-allowed transition"
                    disabled={isSaving || answeredCount !== totalQuestions} 
                >
                    {isSaving ? 'กำลังบันทึกผล...' : 'ส่งคำตอบ (Submit)'}
                </button>
            </div>
        </div>
    );
}