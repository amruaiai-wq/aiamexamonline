// src/app/test/[testId]/page.tsx
export const revalidate = 0; 

import { createSupabaseServerClient } from '@/lib/supabase/server'; 
import Link from 'next/link';

import QuestionRenderer from './question-renderer'; 

// ... (Interface Question และ TestProps เหมือนเดิม) ...

export default async function TestPage({ params }: TestProps) {
  const testId = params.testId;
  const supabase = createSupabaseServerClient();
  
  // 1. ตรวจสอบสถานะ Login ของผู้ใช้ปัจจุบัน
  const { data: userData } = await supabase.auth.getUser();
  const userId = userData.user?.id;
  
  // 2. ตรวจสอบสถานะ Premium จริงๆ ในตาราง Subscriptions
  let isUserPremium = false;
  if (userId) {
    // ดึงสถานะ active จากตาราง Subscriptions
    const { data: subData } = await supabase
      .from('Subscriptions')
      .select('status')
      .eq('user_id', userId)
      .eq('status', 'active') 
      .maybeSingle(); // ใช้ maybeSingle เพราะอาจจะไม่มีข้อมูล
      
    if (subData) {
      isUserPremium = true;
    }
  }

  // 3. ดึงข้อมูลชุดข้อสอบ (ดึง is_premium ของชุดข้อสอบนั้นมา)
  const { data: test, error: testError } = await supabase
    .from('Tests') 
    .select('title, duration_mins, is_premium::boolean') 
    .eq('id', testId)
    .single(); 

  // 4. ดึงโจทย์ (Questions)
  const { data: questions, error: questionsError } = await supabase
    .from('Question') 
    .select('id, test_id, question_text, choices, correct_index, explanation') 
    .eq('test_id', testId); 

  if (questionsError || testError || !test || !questions || questions.length === 0) {
    // ... (โค้ดจัดการ Error เหมือนเดิม)
  }

  // 5. กำหนดสถานะ Paywall Logic
  // Paywall จะถูกเปิดใช้งาน ถ้า: ชุดข้อสอบเป็น Premium AND ผู้ใช้ไม่เป็นสมาชิก Premium
  const isPaywalled = test?.is_premium && !isUserPremium; 
  
  // 6. ส่งสถานะ Paywall ไปที่ QuestionRenderer แทน isPremium
  return (
    <div className="container mx-auto p-8 min-h-screen bg-gray-50">
        
        <div className="flex justify-between items-center mb-6 border-b pb-4 bg-white p-4 rounded-md shadow-sm">
            <h1 className="text-3xl font-bold text-gray-800">{test.title}</h1>
            <div className="text-xl font-semibold text-indigo-600">
                เวลาที่เหลือ: **{test.duration_mins} นาที**
            </div>
        </div>
        
        <QuestionRenderer 
            initialQuestions={questions as Question[]} 
            testTitle={test.title} 
            isPremium={!isPaywalled} // <<<< ส่ง TRUE/FALSE ตามสถานะการเข้าถึง
        />

        <div className='mt-8 text-center'>
            <Link href="/toeic" className="text-indigo-500 hover:underline">
                &larr; กลับสู่หน้ารวมชุดข้อสอบ
            </Link>
        </div>
    </div>
  );
}