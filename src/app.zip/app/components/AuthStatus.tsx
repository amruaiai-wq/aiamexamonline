// src/app/components/AuthStatus.tsx
'use client'; // <<<< ต้องมีบรรทัดนี้เพื่อเปิดใช้งาน State และ Session Listener

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createBrowserClient } from '@supabase/auth-helpers-nextjs'; // ใช้สำหรับ Logout
import { supabase } from '@/lib/supabase/client'; // ใช้สำหรับ getSession และ Listener

export default function AuthStatus() {
    const [userEmail, setUserEmail] = useState<string | null>(null);
    const [isPremium, setIsPremium] = useState(false); // สถานะ Premium
    const router = useRouter();

    // 1. ตรวจสอบสถานะผู้ใช้เมื่อโหลด Component และตั้งค่า Listener
    useEffect(() => {
        // ฟังก์ชันตรวจสอบสถานะ Premium (ในอนาคตจะตรวจสอบตาราง Subscriptions)
        const checkPremiumStatus = async (userId: string) => {
            // NOTE: Logic นี้ถูกทำให้ง่ายเพื่อแสดงป้าย PREMIUM
            // ในแอปพลิเคชันจริงต้องตรวจสอบตาราง Subscriptions
            
            // ตัวอย่าง: ตรวจสอบตาราง Subscriptions
            const { data: subData } = await supabase
                .from('Subscriptions')
                .select('status')
                .eq('user_id', userId)
                .eq('status', 'active') 
                .maybeSingle(); 
                
            setIsPremium(!!subData); // ถ้ามีข้อมูลสถานะ active ให้เป็น true
        };

        const updateAuthStatus = (session: any | null) => {
            if (session?.user) {
                const userEmail = session.user.email || 'ผู้ใช้งาน';
                setUserEmail(userEmail);
                checkPremiumStatus(session.user.id);
            } else {
                setUserEmail(null);
                setIsPremium(false);
            }
        };

        // ดึงสถานะปัจจุบัน
        supabase.auth.getSession().then(({ data: { session } }) => {
            updateAuthStatus(session);
        });

        // ตั้งค่า Listener เพื่ออัปเดตสถานะทันทีเมื่อมีการ Login/Logout
        const { data: authListener } = supabase.auth.onAuthStateChange(
            (event, session) => {
                updateAuthStatus(session);
            }
        );

        // Cleanup function
        return () => {
            authListener?.subscription.unsubscribe();
        };
    }, []);

    const handleLogout = async () => {
        // ใช้ Browser Client ในการ Logout (เพื่อให้โค้ดนี้ทำงานใน Client Component ได้)
        const supabaseClient = createBrowserClient(
            process.env.NEXT_PUBLIC_SUPABASE_URL!,
            process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
        );
        
        await supabaseClient.auth.signOut();
        // นำทางกลับหน้าหลักและ Force Reload เพื่อเคลียร์ Session
        router.push('/');
        window.location.reload(); 
    };

    // 3. แสดงผลตามสถานะ
    if (userEmail) {
        // แสดงปุ่ม Logout และ Dashboard
        return (
            <nav className="flex items-center space-x-4">
                <Link href="/dashboard" className="text-gray-600 hover:text-indigo-600 hidden sm:inline">
                    Dashboard
                </Link>
                {/* ปุ่ม Premium ที่จะแสดงสถานะ */}
                <span className={`px-3 py-1 text-xs font-bold rounded-full ${isPremium ? 'bg-green-500 text-white' : 'bg-yellow-200 text-yellow-800'}`}>
                    {isPremium ? 'PREMIUM' : 'FREE'}
                </span>
                
                <button 
                    onClick={handleLogout}
                    className="px-3 py-1 text-sm bg-red-500 hover:bg-red-600 text-white rounded-lg transition"
                >
                    ออกจากระบบ
                </button>
            </nav>
        );
    }
    
    // แสดงปุ่ม Login เมื่อไม่ได้ Login
    return (
        <nav className="flex items-center space-x-4">
            <Link href="/login" className="text-gray-600 hover:text-indigo-600">
                เข้าสู่ระบบ
            </Link>
            <Link href="/premium" className="text-white bg-indigo-600 hover:bg-indigo-700 px-3 py-1 rounded-lg transition">
                Premium (ปลดล็อกเฉลย)
            </Link>
        </nav>
    );
}