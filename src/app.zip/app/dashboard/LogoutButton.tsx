// src/app/dashboard/LogoutButton.tsx
'use client'; // <<<< ต้องมีบรรทัดนี้เพื่อใช้ useRouter และ onClick

import { useRouter } from 'next/navigation';
import { createBrowserClient } from '@supabase/auth-helpers-nextjs'; 

export default function LogoutButton() {
    const router = useRouter();
    
    const handleLogout = async () => {
        // ใช้ Browser Client ในการ Logout เพื่อเคลียร์ Session ใน Browser
        const supabaseClient = createBrowserClient(
            process.env.NEXT_PUBLIC_SUPABASE_URL!,
            process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
        );
        
        await supabaseClient.auth.signOut();
        router.push('/');
        window.location.reload(); 
    };

    return (
        <button 
            onClick={handleLogout}
            className="mt-8 text-sm text-red-600 hover:underline"
        >
            ออกจากระบบ
        </button>
    );
}