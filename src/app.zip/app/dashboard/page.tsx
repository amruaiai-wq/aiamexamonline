// src/app/dashboard/page.tsx
export const revalidate = 0; // ป้องกัน Cache

import { createSupabaseServerClient } from '@/lib/supabase/server';
import Link from 'next/link';
import { redirect } from 'next/navigation';

// <<<< Import Client Component Logout ที่เราสร้างไว้ >>>>
import LogoutButton from './LogoutButton'; 

// Type สำหรับข้อมูลสถิติ
interface Attempt {
    id: string;
    test_id: string;
    score: number;
    total_questions: number;
    score_percent: number;
    time_spent_secs: number;
    created_at: string;
    user_identifier: string; 
    Tests: {
        title: string;
        exam_category: string;
    } | null;
}


export default async function DashboardPage() {
    const supabase = createSupabaseServerClient();
    
    // 1. ตรวจสอบสถานะ Login
    const { data: userData } = await supabase.auth.getUser();
    const userEmail = userData.user?.email;

    if (!userEmail) {
        // หากผู้ใช้ไม่ได้ Login ให้นำทางไปหน้า Login
        redirect('/login'); 
    }
    
    // 2. ดึงข้อมูลสถิติ (ค้นหาด้วย Email)
    const { data: attempts, error } = await supabase
        .from('TestAttempt')
        .select(`
            id, test_id, score, total_questions, score_percent, created_at, time_spent_secs, user_identifier,
            Tests (title, exam_category)
        `)
        .eq('user_identifier', userEmail) 
        .order('created_at', { ascending: false }); 

    if (error) {
         console.error('Dashboard Error:', error.message);
         // หากมี Error ในการดึงข้อมูล ให้แสดงข้อความแจ้ง
         return <div className="container mx-auto p-8 text-center py-20 min-h-screen text-red-600">
             🚨 เกิดข้อผิดพลาดในการดึงสถิติ: {error.message} (ตรวจสอบ RLS Policy ของ TestAttempt)
         </div>;
    }


    // 3. คำนวณสถิติสรุป (Summary Statistics)
    const totalAttempts = attempts?.length || 0;
    const totalCorrect = attempts?.reduce((sum, a) => sum + a.score, 0) || 0;
    const totalQuestionsDone = attempts?.reduce((sum, a) => sum + a.total_questions, 0) || 0;
    const overallAvg = totalQuestionsDone > 0 ? (totalCorrect / totalQuestionsDone) * 100 : 0;
    const uniqueTestsDone = new Set(attempts?.map(a => a.test_id)).size;


    return (
        <div className="container mx-auto p-8 min-h-screen bg-white">
            <h1 className="text-4xl font-bold text-gray-800 mb-2">ภาพรวมความคืบหน้า 📈</h1>
            <p className="text-2xl text-indigo-600 mb-8">
                ยินดีต้อนรับกลับ, **{userEmail}**!
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Card แสดงคะแนนเฉลี่ยรวม */}
                <div className="p-6 bg-indigo-50 rounded-lg shadow-md border-t-4 border-indigo-600">
                    <p className="text-lg font-semibold text-gray-700">คะแนนเฉลี่ยรวม</p>
                    <h2 className="text-4xl font-bold text-indigo-800 mt-2">
                        {overallAvg.toFixed(1)}%
                    </h2>
                    <p className="text-sm text-gray-500 mt-2">จาก {totalQuestionsDone} ข้อที่ทำแล้ว</p>
                </div>

                {/* Card แสดงชุดข้อสอบที่ทำแล้ว */}
                <div className="p-6 bg-gray-50 rounded-lg shadow-md border-t-4 border-gray-600">
                    <p className="text-lg font-semibold text-gray-700">ชุดข้อสอบที่ทำแล้ว</p>
                    <h2 className="text-4xl font-bold text-gray-800 mt-2">{uniqueTestsDone} ชุด</h2>
                    <p className="text-sm text-gray-500 mt-2">เคยทำซ้ำ {totalAttempts - uniqueTestsDone} ครั้ง</p>
                </div>

                {/* Card แสดงจุดอ่อน (Simple Analysis) */}
                <div className="p-6 bg-red-50 rounded-lg shadow-md border-t-4 border-red-600">
                    <p className="text-lg font-semibold text-gray-700">จุดที่ควรทบทวน</p>
                    <h2 className="text-xl font-bold text-red-800 mt-2">
                         {totalAttempts > 0 ? 'ทบทวนข้อที่ผิด' : '--'}
                    </h2>
                    <p className="text-sm text-gray-500 mt-2">ดูรายละเอียดใน UserAnswer</p>
                </div>
            </div>

            <h3 className="text-3xl font-bold text-gray-800 mt-12 mb-6 border-b pb-2">
                ผลการทำข้อสอบล่าสุด ({totalAttempts})
            </h3>
            
            {/* แสดงตารางผลลัพธ์ล่าสุด */}
            {totalAttempts > 0 ? (
                <div className="overflow-x-auto bg-white rounded-lg shadow">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ชุดข้อสอบ</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">คะแนน</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">เวลา</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">วันที่ทำ</th>
                                <th className="px-6 py-3"></th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {attempts?.map((a: Attempt) => (
                                <tr key={a.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{a.Tests?.title || 'N/A'}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-bold">
                                        {a.score_percent.toFixed(0)}% ({a.score}/{a.total_questions})
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{a.time_spent_secs} วินาที</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {new Date(a.created_at).toLocaleDateString('th-TH')}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <Link href={`/result/${a.id}`} className="text-indigo-600 hover:text-indigo-900">
                                            ดูสรุป &rarr;
                                        </Link>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            ) : (
                <p className="text-gray-500 mt-4">ยังไม่พบผลการทำข้อสอบในบัญชีของคุณ</p>
            )}
            
            {/* ปุ่ม Logout ที่ถูกแยก Component แล้ว */}
            <LogoutButton />
        </div>
    );
}