// src/app/result/[sessionId]/page.tsx

import { createSupabaseServerClient } from '@/lib/supabase/server';
import Link from 'next/link';

// บังคับไม่ให้มีการแคช (เพื่อให้เห็นผลลัพธ์ทันที)
export const revalidate = 0; 

// Type สำหรับรับ Params จาก URL
interface ResultProps {
    params: {
        sessionId: string;
    }
}

// Type ผลลัพธ์จาก Database (ต้องตรงกับคอลัมน์ใน TestAttempt)
interface ResultData {
    id: string;
    test_id: string;
    correct_count: number;
    total_questions: number;
    score_percent: number;
    time_spent_secs: number;
    user_identifier: string;
    // ข้อมูลจากตาราง Tests ที่เชื่อมมา
    Tests: {
        title: string;
        exam_category: string;
    } | null;
}

export default async function ResultPage({ params }: ResultProps) {
    const sessionId = params.sessionId;
    const supabase = createSupabaseServerClient();

    // 1. ดึงข้อมูลผลลัพธ์ (จากตาราง TestAttempt)
    const { data: result, error } = await supabase
        .from('TestAttempt')
        .select(`
            *, 
            Tests (title, exam_category) 
        `) // ดึงข้อมูลจาก Tests ที่เชื่อมโยงมาด้วย
        .eq('id', sessionId)
        .single();

    if (error || !result) {
        return (
            <div className="container mx-auto p-8 text-center py-20 min-h-screen">
                <h3 className="text-3xl font-bold text-red-600">🚨 ไม่พบผลลัพธ์</h3>
                <p className="mt-4 text-gray-600">
                    ไม่พบข้อมูลเซสชัน: {sessionId} (สาเหตุอาจเกิดจาก RLS Policy ของ TestAttempt หรือ TestResults)
                </p>
                <Link href="/" className="text-indigo-500 hover:underline mt-6 block">
                    &larr; กลับสู่หน้าหลัก
                </Link>
            </div>
        );
    }

    const score = result.correct_count;
    const total = result.total_questions;
    const percent = result.score_percent;
    const time = result.time_spent_secs;
    const testTitle = result.Tests?.title || 'ชุดข้อสอบ'; 
    const examCategory = result.Tests?.exam_category.toLowerCase() || 'toeic';

    // กำหนดสีตามคะแนน
    const getScoreColor = (p: number) => {
        if (p >= 75) return '#10B981'; // เขียว
        if (p >= 50) return '#F59E0B'; // เหลือง
        return '#EF4444'; // แดง
    };

    return (
        <div className="container mx-auto p-8 min-h-screen bg-gray-50">
            <div className="max-w-xl mx-auto bg-white p-10 rounded-xl shadow-2xl text-center">
                <h1 className="text-4xl font-extrabold text-gray-800 mb-4">
                    🎉 สรุปผลการทำข้อสอบ!
                </h1>
                <h2 className="text-2xl font-semibold text-gray-700 mb-6">
                    {testTitle}
                </h2>
                <p className="text-gray-600 mb-8">
                    ทำโดย: **{result.user_identifier || 'ไม่ระบุชื่อ'}**
                </p>

                {/* ส่วนสรุปคะแนน */}
                <div className="border-t border-b py-6 mb-6">
                    <p className="text-6xl font-extrabold mb-2" 
                       style={{ color: getScoreColor(percent) }}
                    >
                        {percent.toFixed(0)}%
                    </p>
                    <p className="text-xl font-bold text-gray-800">
                        ถูกต้อง: {score} จาก {total} ข้อ
                    </p>
                </div>

                {/* รายละเอียดเพิ่มเติม */}
                <div className="space-y-3 text-left mb-8">
                    <p className="flex justify-between text-gray-600 border-b pb-1">
                        <span>เวลาที่ใช้ทั้งหมด:</span> 
                        <span className="font-medium text-gray-800">{Math.floor(time / 60)} นาที {time % 60} วินาที</span>
                    </p>
                    {/* ในอนาคตสามารถเพิ่มสถิติแยกตาม Part ตรงนี้ได้ */}
                </div>

                {/* ปุ่มและลิงก์ */}
                <div className="space-y-4">
                    <Link href={`/test/${result.test_id}`} passHref>
                        <button className="w-full px-6 py-3 bg-indigo-600 text-white font-bold rounded-lg hover:bg-indigo-700 transition shadow-md">
                            ดูเฉลยและคำอธิบายอีกครั้ง
                        </button>
                    </Link>
                    <Link href={`/${examCategory}`} passHref>
                        <button className="w-full px-6 py-3 bg-gray-200 text-gray-800 font-medium rounded-lg hover:bg-gray-300 transition">
                            กลับไปหน้าหมวด {examCategory.toUpperCase()}
                        </button>
                    </Link>
                </div>
            </div>
        </div>
    );
}