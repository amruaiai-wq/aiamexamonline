// src/app/page.tsx

import Link from 'next/link';

// ข้อมูลหมวดข้อสอบหลักที่เราตกลงกันไว้
const examCategories = [
  { title: "TOEIC", description: "แบบทดสอบภาษาอังกฤษเพื่อการสื่อสาร", link: "/toeic" },
  { title: "ข้อสอบ ภาค ก. (ก.พ.)", description: "คณิต, ภาษาไทย, กฎหมาย และความรู้เฉพาะ", link: "/khor-kor" },
  { title: "ข้อสอบนายร้อยตำรวจ", description: "เตรียมเข้ารับราชการตำรวจ", link: "/police" },
  { title: "ใบประกอบวิชาชีพครู", description: "จรรยาบรรณ และมาตรฐานวิชาชีพ", link: "/teacher" },
];

export default function HomePage() {
  return (
    // โครงสร้างหลักของหน้า
    <div className="min-h-screen bg-gray-50">
      
      {/* 1. Header Navigation - ส่วนบนสุดของเว็บไซต์ */}
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-indigo-600">
            AiAm Exam Practice
          </h1>
          <nav>
            {/* ในอนาคตจะเพิ่มเมนู Login / Dashboard ตรงนี้ */}
            <Link href="/login" className="text-gray-600 hover:text-indigo-600 mr-4">
                เข้าสู่ระบบ
            </Link>
            <Link href="/premium" className="text-white bg-indigo-600 hover:bg-indigo-700 px-4 py-2 rounded-lg transition">
                Premium
            </Link>
          </nav>
        </div>
      </header>

      {/* 2. Hero Section - ข้อความดึงดูดใจ */}
      <main className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-extrabold text-gray-900 mb-4">
            พิชิตทุกสนามสอบไทย
          </h2>
          <p className="text-xl text-gray-600">
            รวมข้อสอบสำคัญ พร้อมระบบสถิติและเฉลยละเอียดจาก AI
          </p>
        </div>

        {/* 3. Exam Categories - ส่วนแสดงหมวดข้อสอบ */}
        <section>
          <h3 className="text-3xl font-bold text-gray-800 mb-8 text-center">
            เลือกหมวดข้อสอบที่ต้องการฝึกฝน
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {examCategories.map((exam) => (
              // การ์ดข้อสอบแต่ละหมวด
              <Link href={exam.link} key={exam.title} className="block p-6 border-t-4 border-indigo-500 bg-white rounded-xl shadow-lg hover:shadow-xl transform hover:scale-[1.02] transition duration-300">
                <h4 className="text-2xl font-semibold mb-3 text-gray-800">{exam.title}</h4>
                <p className="text-gray-500 mb-4">{exam.description}</p>
                <span className="text-indigo-600 font-medium flex items-center">
                  เริ่มต้นฝึกฝน
                  <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3"></path></svg>
                </span>
              </Link>
            ))}
          </div>
        </section>
      </main>

      {/* 4. Footer */}
      <footer className="bg-gray-800 text-white py-4 mt-12">
        <div className="container mx-auto text-center text-sm">
          © {new Date().getFullYear()} AiAm Exam Practice. All rights reserved.
        </div>
      </footer>
    </div>
  );
}