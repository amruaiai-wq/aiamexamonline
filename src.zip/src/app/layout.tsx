// src/app/layout.tsx

import './globals.css';
import Link from 'next/link';

// ✅ Components (อย่าซ้ำใน page อื่น)
import NamePrompt from '@/components/NamePrompt';
import AuthStatus from '@/components/AuthStatus';

import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'AiAm Exam Practice Online',
  description:
    'ศูนย์รวมข้อสอบ TOEIC ก.พ. ตำรวจ พร้อมเฉลยละเอียดและสถิติส่วนบุคคล',
};

// ✅ Header — แสดงชื่อเว็บและระบบ Login/Logout
function GlobalHeader() {
  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold text-indigo-600">
          AiAm Exam Practice
        </Link>
        <AuthStatus />
      </div>
    </header>
  );
}

// ✅ Footer — แสดงเพียงครั้งเดียว (อย่าซ้ำใน page.tsx)
function GlobalFooter() {
  return (
    <footer className="bg-gray-900 text-gray-300 py-4 mt-12">
      <div className="container mx-auto text-center text-sm">
        © {new Date().getFullYear()} AiAm Exam Practice. All rights reserved.
      </div>
    </footer>
  );
}

// ✅ Root Layout — ตัวหลักของทุกหน้า
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="th">
      <body className="flex flex-col min-h-screen bg-gray-50 text-gray-800">
        <GlobalHeader />

        <main className="flex-grow">{children}</main>

        <GlobalFooter />

        {/* ✅ Popup บังคับใส่ชื่อ (แสดงเฉพาะตอนยังไม่มี userIdentifier) */}
        <NamePrompt />
      </body>
    </html>
  );
}
