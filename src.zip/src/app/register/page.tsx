// src/app/register/page.tsx
'use client'; 

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase/client'; // ใช้ Client Client ในการ SignUp
import Link from 'next/link';

export default function RegisterPage() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const router = useRouter();

    const handleRegister = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        // *** เปลี่ยนจาก signInWithPassword เป็น signUp ***
        const { data, error } = await supabase.auth.signUp({
            email,
            password,
        });

        setLoading(false);

        if (error) {
            alert('สมัครสมาชิกไม่สำเร็จ: ' + error.message);
        } else if (data.user) {
            alert('สมัครสมาชิกสำเร็จ! กรุณาตรวจสอบอีเมลเพื่อยืนยันบัญชี');
            router.push('/login'); // นำทางไปหน้า Login
        }
    };

    return (
        <div className="container mx-auto p-8 min-h-screen flex items-start justify-center pt-20 bg-gray-50">
            <form onSubmit={handleRegister} className="w-full max-w-sm bg-white p-8 rounded-xl shadow-lg border-t-4 border-indigo-600">
                <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">สมัครสมาชิก</h2>
                
                <div className="mb-4">
                    <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">อีเมล</label>
                    <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    />
                </div>
                
                <div className="mb-6">
                    <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">รหัสผ่าน</label>
                    <input
                        type="password"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
                    />
                </div>
                
                <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg focus:outline-none focus:shadow-outline transition duration-150 disabled:opacity-50"
                >
                    {loading ? 'กำลังสมัครสมาชิก...' : 'สมัครสมาชิก'}
                </button>
                
                <p className="text-center text-sm text-gray-600 mt-4">
                    มีบัญชีอยู่แล้ว? <Link href="/login" className="text-indigo-600 hover:underline">เข้าสู่ระบบที่นี่</Link>
                </p>
            </form>
        </div>
    );
}